/*********************************************************************

** Author: Pedro Torres-Picon

** Date: 09/29/2016

** Description: Lab 1 - This is the header file for the readMatrix()
function, which includes the function declaration

*********************************************************************/

#ifndef READMATRIX_HPP
#define READMATRIX_HPP

void readMatrix(int * **arrPtr, int size);

#endif
