/*********************************************************************

** Author: Pedro Torres-Picon

** Date: 09/29/2016

** Description: Lab 1 - This is the header file for the determinant()
function, which includes the function declaration

*********************************************************************/

#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

int determinant(int * **arrPtr, int size);

#endif
